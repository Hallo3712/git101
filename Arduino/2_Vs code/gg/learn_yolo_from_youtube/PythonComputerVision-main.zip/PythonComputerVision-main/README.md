Python Computer Vision: คอร์ส python
Repo สื่อการสอน+แบบฝึกหัด เกี่ยวกับ Computer Vision

ติดตามได้ที่ช่อง Youtube: LouisMakerLab
หรือติดต่อเรียนตัวต่อตัวได้ที่ช่องทาง https://fastwork.co/user/krittachailouis/tutoring-12693427
